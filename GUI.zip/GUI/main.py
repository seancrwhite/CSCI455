import tkinter as tk
from MainWindow import MainWindow

if __name__ == '__main__':
    root = tk.Tk()

    w_main = MainWindow(root)

    root.mainloop()
