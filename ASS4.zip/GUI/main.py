from tkinter import Tk
from MainWindow import MainWindow

if __name__ == '__main__':
    root = Tk()

    w_main = MainWindow(root)
    
    root.mainloop()
